<h1>Bird Browser</h1>
<p>The Bird browser is a browser written in Python and Qt</p>
<p>the browser.ui file can be loaded in the qt-designer.</p>
<p> This is how I want the browser to look at some point</p>
<p>planed features are:</p>
<ul>
<li>Tabs</li>
<li>search engine integration</li>
<li>source-code view</li>
<li>password manager integration</li>
<li>bookmarks</li>
<li>configuration</li>
</ul>
<p>some of these features weren't done by me before
This Project also has an Adblocker build into it.
</p>
<h2>Wiki</h2>
<p>the wiki/manual/cheatsheet can be found <a href="https://github.com/ULUdev/bird-browser/wiki">here</a></p>
<h2>License</h2>
<p><b>GNU GPL 3</b> for more information see the LICENSE file</p>
